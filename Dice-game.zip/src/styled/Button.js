
import styled from 'styled-components';


export const Button = styled.button`
border-radius:5px;
border:none;
padding: 0.625rem 1.125rem;
align-items: center;
background-color: #000;
min-width: 220px;
color: #fff;
cursor: pointer;
border:1px solid transparent;
transition: 0.4s ease-in;

&:hover{
    background-color:#fff;
    border:1px solid #000;
    color:#000;
    transition: 0.3s background ease-in;
}
`;

export const OutlineButton = styled(Button)`

background-color: #fff;
border:1px solid #000;
color:#000;

&:hover{
    background-color:#000;
    border:1px solid transparent;
    color:#fff;
    transition: 0.3s background ease-in;
}
`;
