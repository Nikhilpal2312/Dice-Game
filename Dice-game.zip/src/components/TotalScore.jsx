import React from 'react';
import styled from 'styled-components';

const TotalScore = ({score}) => {
  return (
      <TotalScoreContainer>
        <h1>{score}</h1>
        <p>Total Score</p>
      </TotalScoreContainer>
  )
}

export default TotalScore;

const TotalScoreContainer = styled.div
    
`
max-width:200px;
text-align:center;

h1{
    color: #000;
font-size: 6.25rem;
font-weight: bold;
line-height:80px;
}

p{
    color: #000;
    font-size:1.25rem;
    font-weight:700;
}
`
