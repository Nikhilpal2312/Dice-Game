import styled from 'styled-components';

const RoleDices = ({currentDice, roleDices}) => {
  return (
    <RoleDicesContainer>
      <div className="dice_role" onClick={roleDices}>
      <img src={`/images/dices/dice_${currentDice}.png`} alt='dice 1'/>
      </div>
      <p>Click on Dice to roll</p>
    </RoleDicesContainer>
  )
}

export default RoleDices;


const RoleDicesContainer =styled.div`
margin-top:3rem;
.dice_role{
    display:flex;
    justify-content:center;
}

.dice_role img{
    width:120px;
    cursor: pointer;
}

p{
    text-align: center;
    color:#000;
    font-size: 1rem;
    font-weight: 500;
}

`
