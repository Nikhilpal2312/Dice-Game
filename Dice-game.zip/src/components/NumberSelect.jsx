import React from 'react';
import styled from 'styled-components';

const NumberSelect = ({setError, error, selectedNumber, setSelectedNumber}) => {

    const arrNumber = [1, 2, 3, 4, 5, 6]

    const numberSelectedHandler = (value) => {
        setSelectedNumber(value);
        setError("")
    }

    
    // console.log(selectedNumber)
  return (
    <NumberSelectContainer>
        <p className='error'>{error}</p>
    <div className="flex">
    {
            arrNumber.map((value, i)=>
            <Box isSelected ={value == selectedNumber}key={i} onClick={()=>numberSelectedHandler(value)}>
                {value}</Box>)
        }
    </div>
    <p>Select Number</p>
        
    </NumberSelectContainer>

      
  )
}

export default NumberSelect;

const NumberSelectContainer = styled.div`
.error{
    color: rgb(255, 0, 0);

}

display:flex;
flex-direction: column;
align-items: end;

.flex{
    display: flex;
    gap:1.5rem;
}

P{
    font-size: 1rem;
    font-weight: 700;
}
`;

const Box = styled.div 
`
    width:2.5rem;
    height:2.5rem;
    border:1px solid #000;
    font-size:1rem;
    font-weight:bold;
    display:grid;
    place-items:center;
    cursor:pointer;
    background-color: ${(props)=> (props.isSelected ? "#000" : "#fff")};
    color: ${(props)=> (!props.isSelected ? "#000" : "#fff")};

`;
