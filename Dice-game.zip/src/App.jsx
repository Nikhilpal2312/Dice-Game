import React, {useState} from 'react';
import './App.css';
import GameStart from './components/GameStart';
import GamePlay from './components/GamePlay';


function App() {

  const [isGameStart, setIsGameStart]=useState(false);

  const toggleGamePlay= () => {

    setIsGameStart ((prev) => !prev)
  }


  return (
    <>
    {isGameStart ? <GamePlay/> : <GameStart toggle ={toggleGamePlay}/>}
    </> 
  )
}

export default App;
